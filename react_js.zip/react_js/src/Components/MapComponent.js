import * as React from 'react';
import { Map, loadModules } from 'react-arcgis';
import mapPoints from '../Data/outlets.geo.json'
import { fields, pTemplate, pointsRenderer } from '../Data/LayerDescription'

export default class MakeAMap extends React.Component {

    state = {
        map: null,
        view: null,
        airEnabled: true,
        landEnabled: true,
        seaEnabled: true,
        checkedVisiablityBefore: false,
    };

    layer = null;
    homeBtn = null;

    componentDidMount() {
        document.addEventListener("message", (data) => {
            let option = data.data.split("_")
            let optionname = option[0];
            let isEnabled = option[1];

            switch (optionname) {
                case 'air':
                    this.setState({
                        airEnabled: isEnabled == "true" ? true : false
                    }, () => {
                        this.filterMap();
                    });
                    break;
                case 'land':
                    this.setState({
                        landEnabled: isEnabled == "true" ? true : false
                    }, () => {
                        this.filterMap();
                    });
                    break;
                case 'sea':
                    this.setState({
                        seaEnabled: isEnabled == "true" ? true : false
                    }, () => {
                        this.filterMap();
                    });
                    break;
                case 'close':
                    this.state.view.popup.close()
                    this.zoomToFullExtentHandeler()
                    break;
                default:
                    alert("Wrong Message")
            }
        });
    }

    filterMap = () => {
        let query = this.PrepareQuery();
        this.layer.definitionExpression = query
    }

    PrepareQuery = () => {
        let query = "";
        if (this.state.airEnabled) {
            query += "type='air'"
        }
        if (this.state.landEnabled) {
            if (query.length > 0)
                query += " or type='land'"
            else
                query += "type='land'"
        }
        if (this.state.seaEnabled) {
            if (query.length > 0)
                query += " or type='sea'"
            else
                query += "type='sea'"
        }
        if (query.length == 0)
            query += "type='x'"
        return query;
    }

    mapLoadedHandeler = (map, view) => {

        this.setState({ map, view });

        loadModules(["esri/Basemap", "esri/widgets/BasemapToggle", 'esri/layers/MapImageLayer', 'esri/layers/FeatureLayer', 'esri/geometry/Point', 'esri/geometry/Extent', "esri/widgets/Home"]).then(([Basemap, BasemapToggle, MapImageLayer, FeatureLayer, Point, Extent, Home]) => {

            var dynamicLayer = new MapImageLayer({
                url: "http://nsdig2gapps.ncsi.gov.om/arcgis/rest/services/Base_Map_EN/MapServer",
                title: "Basemap"
            });

            map.basemap = new Basemap({
                baseLayers: [
                    dynamicLayer
                ]
            });

            view.extent = new Extent({
                xmin: 52.00000000000006,
                ymin: 16.650262848000068,
                xmax: 59.839432059000046,
                ymax: 26.507433585000058,
                spatialReference: {
                    wkid: 4326
                }
            });

            view.on("resize", () => { this.zoomToFullExtentHandeler() });

            var popup = view.popup;
            popup.dockEnabled = false;
            popup.collapseEnabled = false;
            popup.overwriteActions = true;
            popup.autoCloseEnabled = true;
            popup.viewModel.on("trigger-action", (event) => {
                if (event.action.id === "ZoomTo") {
                    this.state.view.goTo({
                        target: popup.viewModel.selectedFeature.geometry,
                        zoom: 16
                    });
                    this.featureZoomHandeler(event, event.target.features[0].attributes)
                }
            });

            let graphics = mapPoints.features.map(function (feature, i) {
                return {
                    geometry: new Point({
                        x: feature.geometry.coordinates[0],
                        y: feature.geometry.coordinates[1]
                    }),
                    // select only the attributes you care about
                    attributes: {
                        ObjectID: i,
                        NAME_EN: feature.properties.NAME_EN,
                        ENG_DESC: feature.properties.ENG_DESC,
                        type: feature.properties.type,
                        POE_CODE: feature.properties.POE_CODE
                    }
                };
            });

            this.layer = new FeatureLayer(
                {
                    renderer: pointsRenderer,
                    fields: fields,
                    source: graphics,
                    objectIdField: "ObjectID",
                    spatialReference: {
                        wkid: 4326
                    },
                    geometryType: "point",
                    popupTemplate: pTemplate,
                    title: "Ports"
                }

            );
            map.add(this.layer);


            this.homeBtn = new Home({
                view: view
            });

            this.homeBtn.on("go", (event) => {
                window.postMessage("close");
            });

            var toggle = new BasemapToggle({
                view: view,
                nextBasemap: "satellite"
            });



            view.ui.add(this.homeBtn, "top-left");
            view.ui.add(toggle, "top-left");

            view.popup.watch("visible", (visible) => {
                if (visible === true) {
                    var popup = document.getElementsByClassName('esri-popup__main-container')[0];
                    popup.addEventListener("click", (event) => {
                        let popupBtn = document.getElementsByClassName('customZoominBtn')[0];
                        popupBtn.click();
                    }, { once: true });
                }

            });

        });
    }


    zoomToFullExtentHandeler() {

        this.state.view.goTo({
            target: this.state.view.center,
            zoom: 5
        });

    }

    featureZoomHandeler(event, feature) {
        let featureJSON = JSON.stringify(feature)
        window.postMessage(featureJSON);
       
    }

    render() {
        return (

            <div style={{ width: '100vw', height: '100vh' }}>
                <Map
                    class="full-screen-map" onLoad={this.mapLoadedHandeler}
                />
            </div>
        );
    }
}
