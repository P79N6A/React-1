import React, { Component } from 'react';
import MapComponent from './Components/MapComponent'
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
       <MapComponent/>
      </div>
    );
  }
}

export default App;
