const fields = [
    {
        name: "ObjectID",
        alias: "ObjectID",
        type: "oid"
    },
    {
        name: "NAME_EN",
        alias: "Name",
        type: "string"
    },
    {
        name: "ENG_DESC",
        alias: "Description",
        type: "string"
    },
    {
        name: "type",
        alias: "Type",
        type: "string"
    }
    , {
        name: "POE_CODE",
        alias: "POE Code",
        type: "double"
    }

];

// Set up popup template for the layer
const pTemplate = {
    content:"{ENG_DESC}",
    actions:[{
        id: "ZoomTo",
        title: "zoom to",
        className: "esri-icon-zoom-in-magnifying-glass customZoominBtn"
      }]
};


const pointsRenderer = {


    type: "unique-value",  // autocasts as new UniqueValueRenderer()
    field: "type",
    defaultSymbol: { type: "simple-marker" },
    uniqueValueInfos: [{
        value: "air",
        label:"Air",
        symbol: {
            type: "simple-marker",  // autocasts as new SimpleMarkerSymbol()
            color: [250 ,190, 0],
            size: "13px",  // pixels
        }
    }, {
        value: "sea",
        label:"Sea",        
        symbol: {
            type: "simple-marker",  // autocasts as new SimpleMarkerSymbol()
            color: [23,155,252],
            size: "13px",  // pixels
        }
    }, {
        value: "land",
        label:"Land",
        symbol: {
            type: "simple-marker",  // autocasts as new SimpleMarkerSymbol()
            color: [0 ,220, 1],
            size: "13px",  // pixels
        }
    }
    ],
};

export { fields, pTemplate, pointsRenderer }